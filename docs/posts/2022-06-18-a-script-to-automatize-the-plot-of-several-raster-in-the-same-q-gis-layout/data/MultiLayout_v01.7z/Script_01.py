# Parameters
pathProject = r"B:\Documents\Scripts\MultiLayout\MultiLayout.qgz"
# Add path to tsv data-sheet
tsv_path = r"B:\Documents\Scripts\MultiLayout\_Release_01\MultiLayout.tsv.txt"
################################################################################
import qgis, os, sys, sysconfig, ntpath
# convert path into qgis query for tsv text files from excel
tsv_qgisquery = 'file:///' + tsv_path + '?encoding=ANSI1251&type=csv&delimiter=%5Ct&maxFields=10000&detectTypes=yes&geomType=none&subsetIndex=no&watchFile=no'
# Set datasheet to be imported
datasheet = QgsVectorLayer(tsv_qgisquery,'datasheet', 'delimitedtext')
# Load Layout
project = QgsProject.instance()
# Print the current project file name (might be empty in case no projects have been loaded)
print(project.fileName())
# Load another project
project.read(pathProject)
manager = project.layoutManager()
layout = QgsPrintLayout(project)

# Import as a layer into the project
QgsProject.instance().addMapLayer(datasheet)

for feature in datasheet.getFeatures():
    # Load Layout
    layout = manager.layoutByName(feature['Layout'])
    item_title = layout.itemById('title')
    item_disclaimer = layout.itemById('disclaimer')
    item_map = layout.itemById('map')
    item_legend = layout.itemById('legend')
    item_north = layout.itemById('north')
    item_scalebar = layout.itemById('scalebar')
    # Change Layout
    item_title.setText(feature['Title'])
    item_disclaimer.setText(feature['Disclaimer'])
    # Add Raster and style
    layer_raster = iface.addRasterLayer(feature['RasterPath_01'],ntpath.basename(feature['RasterPath_01']))
    layer_raster.loadNamedStyle(feature['RasterStyle_01'])
    # Export Layout
    exporter = QgsLayoutExporter(layout)
    exporter.exportToImage(feature['ExportPath'], QgsLayoutExporter.ImageExportSettings())
    # Remove Layer
    layer = QgsProject.instance().mapLayersByName(ntpath.basename(feature['RasterPath_01']))[0]
    QgsProject.instance().removeMapLayer(layer)
    # Indicator
    print(feature['Title'])

QgsProject.instance().removeMapLayer(QgsProject.instance().mapLayersByName('datasheet')[0])