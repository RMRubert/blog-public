//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CX2388xRes.rc
//
#define IDC_STATIC                      -1
#define IDD_DIALOG1                     101
#define IDD_CX2388XREGISTER_EDIT        101
#define IDC_REGISTER                    1001
#define IDC_REGISTERSELECT              1001
#define IDC_BIT0                        1002
#define IDC_BIT1                        1003
#define IDC_BIT2                        1004
#define IDC_BIT3                        1005
#define IDC_BIT4                        1006
#define IDC_BIT5                        1007
#define IDC_BIT6                        1008
#define IDC_BIT7                        1009
#define IDC_BIT8                        1010
#define IDC_BIT9                        1011
#define IDC_BIT10                       1012
#define IDC_BIT11                       1013
#define IDC_BIT12                       1014
#define IDC_BIT13                       1015
#define IDC_BIT14                       1016
#define IDC_BIT15                       1017
#define IDC_BIT16                       1018
#define IDC_BIT17                       1019
#define IDC_BIT18                       1020
#define IDC_BIT19                       1021
#define IDC_BIT20                       1022
#define IDC_BIT21                       1023
#define IDC_BIT22                       1024
#define IDC_BIT23                       1025
#define IDC_BIT24                       1026
#define IDC_BIT25                       1027
#define IDC_BIT26                       1028
#define IDC_BIT27                       1029
#define IDC_BIT28                       1030
#define IDC_BIT29                       1031
#define IDC_BIT30                       1032
#define IDC_BIT31                       1033
#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
