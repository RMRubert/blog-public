//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SAA7134Res.rc
//
#define IDC_STATIC                      -1
#define IDC_LEFT_SLIDER                 1001
#define IDC_LEFT_EDIT                   1002
#define IDC_NICAM_SLIDER                1003
#define IDC_NICAM_EDIT                  1004
#define IDC_RIGHT_SLIDER                1005
#define IDC_RIGHT_EDIT                  1006
#define IDC_LINKED_CHECK                1007
#define IDC_BLUR_SLIDER                 1008
#define IDC_AUTOBLUR_CHECK              1009
#define IDC_BLUR_EDIT                   1010
#define IDC_REFRESH                     1415
#define IDC_SEND                        1417
#define IDC_SIGNED                      1434
#define IDC_ENDIANCHECK                 1436
#define IDC_MASKCHECK                   1437
#define IDC_AUTOWRITE                   1438
#define IDC_SETBIT0                     1440
#define IDC_SETBIT1                     1441
#define IDC_SETBIT2                     1442
#define IDC_SETBIT3                     1443
#define IDC_SETBIT4                     1444
#define IDC_SETBIT5                     1445
#define IDC_SETBIT6                     1446
#define IDC_SETBIT7                     1447
#define IDC_VALUE_DEC                   1523
#define IDC_VALUE_HEX                   1524
#define IDC_SEL_BIT0                    1734
#define IDC_SEL_BIT1                    1735
#define IDC_SEL_BIT2                    1736
#define IDC_SEL_BIT3                    1737
#define IDC_SEL_BIT4                    1738
#define IDC_SEL_BIT5                    1739
#define IDC_SEL_BIT6                    1740
#define IDC_SEL_BIT7                    1741
#define IDC_SEL_BIT8                    1742
#define IDC_REGISTERSELECT              8052
#define IDC_VALUE_SLIDER                8053
#define IDC_WORDCHECK                   8054
#define IDC_BIT0                        8055
#define IDC_BIT1                        8056
#define IDC_BIT2                        8057
#define IDC_BIT3                        8058
#define IDC_BIT4                        8059
#define IDC_BIT5                        8060
#define IDC_BIT6                        8061
#define IDC_BIT7                        8062
#define IDC_STATIC_BIT0                 8063
#define IDC_STATIC_BIT1                 8064
#define IDC_STATIC_BIT2                 8065
#define IDC_STATIC_BIT3                 8066
#define IDC_STATIC_BIT4                 8067
#define IDC_STATIC_BIT5                 8068
#define IDC_STATIC_BIT6                 8069
#define IDC_STATIC_BIT7                 8070
#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
