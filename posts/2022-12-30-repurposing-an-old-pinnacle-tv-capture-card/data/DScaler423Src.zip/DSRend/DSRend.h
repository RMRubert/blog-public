

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 7.00.0500 */
/* at Tue Jul 28 08:59:23 2015
 */
/* Compiler settings for .\DSRend.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __DSRend_h__
#define __DSRend_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IDSRendFilter_FWD_DEFINED__
#define __IDSRendFilter_FWD_DEFINED__
typedef interface IDSRendFilter IDSRendFilter;
#endif 	/* __IDSRendFilter_FWD_DEFINED__ */


#ifndef __IDSRendSettings_FWD_DEFINED__
#define __IDSRendSettings_FWD_DEFINED__
typedef interface IDSRendSettings IDSRendSettings;
#endif 	/* __IDSRendSettings_FWD_DEFINED__ */


#ifndef __DSRendFilter_FWD_DEFINED__
#define __DSRendFilter_FWD_DEFINED__

#ifdef __cplusplus
typedef class DSRendFilter DSRendFilter;
#else
typedef struct DSRendFilter DSRendFilter;
#endif /* __cplusplus */

#endif 	/* __DSRendFilter_FWD_DEFINED__ */


#ifndef __DSRendInPin_FWD_DEFINED__
#define __DSRendInPin_FWD_DEFINED__

#ifdef __cplusplus
typedef class DSRendInPin DSRendInPin;
#else
typedef struct DSRendInPin DSRendInPin;
#endif /* __cplusplus */

#endif 	/* __DSRendInPin_FWD_DEFINED__ */


#ifndef __DSRendQualityPage_FWD_DEFINED__
#define __DSRendQualityPage_FWD_DEFINED__

#ifdef __cplusplus
typedef class DSRendQualityPage DSRendQualityPage;
#else
typedef struct DSRendQualityPage DSRendQualityPage;
#endif /* __cplusplus */

#endif 	/* __DSRendQualityPage_FWD_DEFINED__ */


#ifndef __SettingsPage_FWD_DEFINED__
#define __SettingsPage_FWD_DEFINED__

#ifdef __cplusplus
typedef class SettingsPage SettingsPage;
#else
typedef struct SettingsPage SettingsPage;
#endif /* __cplusplus */

#endif 	/* __SettingsPage_FWD_DEFINED__ */


#ifndef __DSRendAboutPage_FWD_DEFINED__
#define __DSRendAboutPage_FWD_DEFINED__

#ifdef __cplusplus
typedef class DSRendAboutPage DSRendAboutPage;
#else
typedef struct DSRendAboutPage DSRendAboutPage;
#endif /* __cplusplus */

#endif 	/* __DSRendAboutPage_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "strmif.h"

#ifdef __cplusplus
extern "C"{
#endif 


/* interface __MIDL_itf_DSRend_0000_0000 */
/* [local] */ 

typedef /* [public][public][public] */ 
enum __MIDL___MIDL_itf_DSRend_0000_0000_0001
    {	BUFFER_FLAGS_FIELD_UNKNOWN	= 0,
	BUFFER_FLAGS_FIELD_ODD	= 0x1,
	BUFFER_FLAGS_FIELD_EVEN	= 0x2
    } 	BUFFER_FLAGS;

typedef /* [helpstring] */ struct _FieldBuffer
    {
    BYTE *pBuffer;
    BUFFER_FLAGS flags;
    } 	FieldBuffer;

typedef /* [public][public][helpstring] */ struct __MIDL___MIDL_itf_DSRend_0000_0000_0002
    {
    long Width;
    long Height;
    int CurrentFrame;
    BOOL bIsField;
    } 	BufferInfo;



extern RPC_IF_HANDLE __MIDL_itf_DSRend_0000_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_DSRend_0000_0000_v0_0_s_ifspec;

#ifndef __IDSRendFilter_INTERFACE_DEFINED__
#define __IDSRendFilter_INTERFACE_DEFINED__

/* interface IDSRendFilter */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IDSRendFilter;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("22A829B8-C04A-4102-9A2C-45E54CED56D3")
    IDSRendFilter : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetFieldHistory( 
            /* [in] */ long cFields) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetFields( 
            /* [out][in] */ FieldBuffer *ppFields,
            /* [out][in] */ long *count,
            BufferInfo *pBufferInfo,
            /* [in] */ DWORD dwTimeout,
            /* [in] */ DWORD dwLastRenderTime) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE FreeFields( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDSRendFilterVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IDSRendFilter * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IDSRendFilter * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IDSRendFilter * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *SetFieldHistory )( 
            IDSRendFilter * This,
            /* [in] */ long cFields);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *GetFields )( 
            IDSRendFilter * This,
            /* [out][in] */ FieldBuffer *ppFields,
            /* [out][in] */ long *count,
            BufferInfo *pBufferInfo,
            /* [in] */ DWORD dwTimeout,
            /* [in] */ DWORD dwLastRenderTime);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE *FreeFields )( 
            IDSRendFilter * This);
        
        END_INTERFACE
    } IDSRendFilterVtbl;

    interface IDSRendFilter
    {
        CONST_VTBL struct IDSRendFilterVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDSRendFilter_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IDSRendFilter_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IDSRendFilter_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IDSRendFilter_SetFieldHistory(This,cFields)	\
    ( (This)->lpVtbl -> SetFieldHistory(This,cFields) ) 

#define IDSRendFilter_GetFields(This,ppFields,count,pBufferInfo,dwTimeout,dwLastRenderTime)	\
    ( (This)->lpVtbl -> GetFields(This,ppFields,count,pBufferInfo,dwTimeout,dwLastRenderTime) ) 

#define IDSRendFilter_FreeFields(This)	\
    ( (This)->lpVtbl -> FreeFields(This) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IDSRendFilter_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_DSRend_0000_0001 */
/* [local] */ 

typedef /* [public][public] */ struct __MIDL___MIDL_itf_DSRend_0000_0001_0001
    {
    BOOL bNeedConv;
    BOOL bFieldInput;
    LONG Width;
    LONG Height;
    } 	DSRendStatus;

typedef /* [public][public][public] */ 
enum __MIDL___MIDL_itf_DSRend_0000_0001_0002
    {	DSREND_FIELD_FORMAT_AUTO	= 0,
	DSREND_FIELD_FORMAT_FRAME	= ( DSREND_FIELD_FORMAT_AUTO + 1 ) ,
	DSREND_FIELD_FORMAT_FIELD	= ( DSREND_FIELD_FORMAT_FRAME + 1 ) 
    } 	DSREND_FIELD_FORMAT;



extern RPC_IF_HANDLE __MIDL_itf_DSRend_0000_0001_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_DSRend_0000_0001_v0_0_s_ifspec;

#ifndef __IDSRendSettings_INTERFACE_DEFINED__
#define __IDSRendSettings_INTERFACE_DEFINED__

/* interface IDSRendSettings */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IDSRendSettings;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("20605312-3D0E-4DB3-A17D-67436CA009AA")
    IDSRendSettings : public IUnknown
    {
    public:
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Status( 
            /* [retval][out] */ DSRendStatus *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_SwapFields( 
            /* [retval][out] */ BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_SwapFields( 
            /* [in] */ BOOL newVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ForceYUY2( 
            /* [retval][out] */ BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_ForceYUY2( 
            /* [in] */ BOOL newVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_FieldFormat( 
            /* [retval][out] */ DSREND_FIELD_FORMAT *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_FieldFormat( 
            /* [in] */ DSREND_FIELD_FORMAT newVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_VertMirror( 
            /* [retval][out] */ BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_VertMirror( 
            /* [in] */ BOOL newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDSRendSettingsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IDSRendSettings * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IDSRendSettings * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IDSRendSettings * This);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Status )( 
            IDSRendSettings * This,
            /* [retval][out] */ DSRendStatus *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_SwapFields )( 
            IDSRendSettings * This,
            /* [retval][out] */ BOOL *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE *put_SwapFields )( 
            IDSRendSettings * This,
            /* [in] */ BOOL newVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ForceYUY2 )( 
            IDSRendSettings * This,
            /* [retval][out] */ BOOL *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ForceYUY2 )( 
            IDSRendSettings * This,
            /* [in] */ BOOL newVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_FieldFormat )( 
            IDSRendSettings * This,
            /* [retval][out] */ DSREND_FIELD_FORMAT *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE *put_FieldFormat )( 
            IDSRendSettings * This,
            /* [in] */ DSREND_FIELD_FORMAT newVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE *get_VertMirror )( 
            IDSRendSettings * This,
            /* [retval][out] */ BOOL *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE *put_VertMirror )( 
            IDSRendSettings * This,
            /* [in] */ BOOL newVal);
        
        END_INTERFACE
    } IDSRendSettingsVtbl;

    interface IDSRendSettings
    {
        CONST_VTBL struct IDSRendSettingsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDSRendSettings_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IDSRendSettings_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IDSRendSettings_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IDSRendSettings_get_Status(This,pVal)	\
    ( (This)->lpVtbl -> get_Status(This,pVal) ) 

#define IDSRendSettings_get_SwapFields(This,pVal)	\
    ( (This)->lpVtbl -> get_SwapFields(This,pVal) ) 

#define IDSRendSettings_put_SwapFields(This,newVal)	\
    ( (This)->lpVtbl -> put_SwapFields(This,newVal) ) 

#define IDSRendSettings_get_ForceYUY2(This,pVal)	\
    ( (This)->lpVtbl -> get_ForceYUY2(This,pVal) ) 

#define IDSRendSettings_put_ForceYUY2(This,newVal)	\
    ( (This)->lpVtbl -> put_ForceYUY2(This,newVal) ) 

#define IDSRendSettings_get_FieldFormat(This,pVal)	\
    ( (This)->lpVtbl -> get_FieldFormat(This,pVal) ) 

#define IDSRendSettings_put_FieldFormat(This,newVal)	\
    ( (This)->lpVtbl -> put_FieldFormat(This,newVal) ) 

#define IDSRendSettings_get_VertMirror(This,pVal)	\
    ( (This)->lpVtbl -> get_VertMirror(This,pVal) ) 

#define IDSRendSettings_put_VertMirror(This,newVal)	\
    ( (This)->lpVtbl -> put_VertMirror(This,newVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IDSRendSettings_INTERFACE_DEFINED__ */



#ifndef __DSRENDLib_LIBRARY_DEFINED__
#define __DSRENDLib_LIBRARY_DEFINED__

/* library DSRENDLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_DSRENDLib;

EXTERN_C const CLSID CLSID_DSRendFilter;

#ifdef __cplusplus

class DECLSPEC_UUID("29383BF2-74DD-4F7F-A3D0-A00ABE5D966D")
DSRendFilter;
#endif

EXTERN_C const CLSID CLSID_DSRendInPin;

#ifdef __cplusplus

class DECLSPEC_UUID("F4DA29E0-5C4D-4C69-8545-A5B94F51578A")
DSRendInPin;
#endif

EXTERN_C const CLSID CLSID_DSRendQualityPage;

#ifdef __cplusplus

class DECLSPEC_UUID("02FA8EB3-9D40-4764-9D04-173BDB52D4A7")
DSRendQualityPage;
#endif

EXTERN_C const CLSID CLSID_SettingsPage;

#ifdef __cplusplus

class DECLSPEC_UUID("8AC05775-495A-435A-A143-A1002657E584")
SettingsPage;
#endif

EXTERN_C const CLSID CLSID_DSRendAboutPage;

#ifdef __cplusplus

class DECLSPEC_UUID("495D7645-48CF-4B3F-AF26-61CC5F03B4DF")
DSRendAboutPage;
#endif
#endif /* __DSRENDLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


