//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DSRend.rc
//
#define IDC_STATIC                      -1
#define IDS_PROJNAME                    100
#define IDR_DSRENDFILTER                101
#define IDR_DSRENDINPIN                 102
#define IDS_TITLEDSRendQualityPage      103
#define IDS_HELPFILEDSRendQualityPage   104
#define IDS_DOCSTRINGDSRendQualityPage  105
#define IDR_DSRENDQUALITYPAGE           106
#define IDD_DSRENDQUALITYPAGE           107
#define IDS_TITLESettingsPage           108
#define IDS_HELPFILESettingsPage        109
#define IDS_DOCSTRINGSettingsPage       110
#define IDR_SETTINGSPAGE                111
#define IDD_SETTINGSPAGE                112
#define IDS_TITLEDSRendAboutPage        113
#define IDS_HELPFILEDSRendAboutPage     114
#define IDS_DOCSTRINGDSRendAboutPage    115
#define IDR_DSRENDABOUTPAGE             116
#define IDD_DSRENDABOUTPAGE             117
#define IDC_AVG_FRAME_RATE              1000
#define IDC_AVG_SYNC_OFFSET             1001
#define IDC_STDDEV_SYNC_OFFSET          1002
#define IDC_FRAMES_DRAWN                1003
#define IDC_FRAMES_DROPPED              1004
#define IDC_JITTER                      1005
#define IDC_UPSTREAM_DROPPED            1006
#define IDC_UPSTREAM_NOTDROPPED         1007
#define IDC_UPSTREAM_AVGSIZE            1008
#define IDC_UPSTREAM_GRP                1009
#define IDC_UPSTREAM_LBL1               1010
#define IDC_UPSTREAM_LBL2               1011
#define IDC_UPSTREAM_LBL3               1012
#define IDC_RESET                       1013
#define IDC_RESTORE                     1014
#define IDC_SETTINGSPAGE_FIELDFORMAT    1015
#define IDC_SETTINGSPAGE_FORCEYUY2      1016
#define IDC_SETTINGSPAGE_SWAPFIELDS     1017
#define IDC_SETTINGSPAGE_VERTMIRROR     1018
#define IDC_SETTINGSPAGE_FIELD          1019
#define IDC_SETTINGSPAGE_COLORCNV       1020
#define IDC_SETTINGSPAGE_SIZE           1021
#define IDC_ABOUT_COMPILEDATE           1023
#define IDC_ABOUT_VERSION               1025
#define IDC_ABOUT_LINE1                 1026
#define IDC_ABOUT_LINE2                 1027
#define IDC_ABOUT_LINE3                 1028
#define IDC_ABOUT_GRP1                  1029
#define IDC_ABOUT_GRP2                  1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        212
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           118
#endif
#endif
