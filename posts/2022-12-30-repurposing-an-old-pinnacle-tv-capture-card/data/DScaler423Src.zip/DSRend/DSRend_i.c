

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 7.00.0500 */
/* at Tue Jul 28 08:59:23 2015
 */
/* Compiler settings for .\DSRend.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_IDSRendFilter,0x22A829B8,0xC04A,0x4102,0x9A,0x2C,0x45,0xE5,0x4C,0xED,0x56,0xD3);


MIDL_DEFINE_GUID(IID, IID_IDSRendSettings,0x20605312,0x3D0E,0x4DB3,0xA1,0x7D,0x67,0x43,0x6C,0xA0,0x09,0xAA);


MIDL_DEFINE_GUID(IID, LIBID_DSRENDLib,0x694D6921,0xE73C,0x40C0,0x9F,0x75,0x5B,0xC4,0xFA,0x64,0x6D,0xF7);


MIDL_DEFINE_GUID(CLSID, CLSID_DSRendFilter,0x29383BF2,0x74DD,0x4F7F,0xA3,0xD0,0xA0,0x0A,0xBE,0x5D,0x96,0x6D);


MIDL_DEFINE_GUID(CLSID, CLSID_DSRendInPin,0xF4DA29E0,0x5C4D,0x4C69,0x85,0x45,0xA5,0xB9,0x4F,0x51,0x57,0x8A);


MIDL_DEFINE_GUID(CLSID, CLSID_DSRendQualityPage,0x02FA8EB3,0x9D40,0x4764,0x9D,0x04,0x17,0x3B,0xDB,0x52,0xD4,0xA7);


MIDL_DEFINE_GUID(CLSID, CLSID_SettingsPage,0x8AC05775,0x495A,0x435A,0xA1,0x43,0xA1,0x00,0x26,0x57,0xE5,0x84);


MIDL_DEFINE_GUID(CLSID, CLSID_DSRendAboutPage,0x495D7645,0x48CF,0x4B3F,0xAF,0x26,0x61,0xCC,0x5F,0x03,0xB4,0xDF);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



